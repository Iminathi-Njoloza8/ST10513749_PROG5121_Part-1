/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {

        try (Scanner input = new Scanner(System.in)) {
            Login login = new Login();
            
            String username;
            String password;
            String phoneNumber;
            
            //=== REGISTRATION SECTION ===
            System.out.println("=== Register User ===");
            
            // This is when the username is not formatted correctly
            while (true) {
                System.out.print("Enter username: ");
                username = input.nextLine();
                
                if (login.checkUserName(username)) {
                    break;
                } else {
                    System.out.println("Invalid username. Must contain '_' and be no more than 5 characters.");
                }
            }
            
            // This is when the password is not formatted correctly
            while (true) {
                System.out.print("Enter password: ");
                password = input.nextLine();
                
                if (login.checkPasswordComplexity(password)) {
                    break;
                } else {
                    System.out.println("Invalid password. Must be 8+ chars, include capital, number, and special character.");
                }
            }
            
            // This is when the cellphone number is not formatted correctly
            while (true) {
                System.out.print("Enter phone number (+27...): ");
                phoneNumber = input.nextLine();
                
                if (login.checkCellPhoneNumber(phoneNumber)) {
                    break;
                } else {
                    System.out.println("Invalid phone number. Must start with +27 and be 12 digits.");
                }
            }
            
            // This is when all inputs are valid
            String result = login.registerUser(username, password, phoneNumber);
            System.out.println(result);
            
            // === LOGIN SECTION ===
            System.out.println("\n=== Login ===");
            
            System.out.print("Enter username: ");
            String loginUser = input.nextLine();
            
            System.out.print("Enter password: ");
            String loginPass = input.nextLine();
            
            boolean success = login.loginUser(loginUser, loginPass);
            System.out.println(login.returnLoginStatus(success));
        }
    }
}
